﻿using System;
using System.Collections;
using System.Text.Json;

//Class
public class News
{
    private int id;
    private long time;
    private string content;
    private string[] keywords;
    private int hits;

    public int ID { get => id; set => id = value; }
    public long Time { get => time; set => time = value; }
    public string Content { get => content; set => content = value; }
    public string[] Keywords { get => keywords; set => keywords = value; }
    public int Hits { get => hits; set => hits = value; }

}

//Node
public class Node{
    public News data;
    public int priority;
    public Node next;

    public Node(News data, int priority)
    {
        this.data = data;
        this.priority = priority;
        this.next = null;
    }
}

public class RecentNode
{
    public News Value { get; set; }
    public RecentNode Next { get; set; }
    public RecentNode Previous { get; set; }

    public RecentNode(News value)
    {
        Value = value;
        Next = null;
        Previous = null;
    }
}

/*
public class LRUNode
{
    public int Key { get; set; }
    public News Value { get; set; }
    public LRUNode Previous { get; set; }
    public LRUNode Next { get; set; }

    public LRUNode()
    {

    }
    public LRUNode(int key, News value)
    {
        Key = key; 
        Value = value;
    }
}
*/


// LRU

/*
public class LRUCache
{
    private int capacity;
    private int count;
    Dictionary<int, LRUNode> map;
    RecentNewsLinkedList recentNewsList = new RecentNewsLinkedList();

    public LRUCache(int capacity)
    {
        this.capacity = capacity;
        count = 0;
        map = new Dictionary<int, LRUNode>();
        recentNewsList = new RecentNewsLinkedList();
    }

    public News Get(int key)
    {
        // at each access of the node, we move it to the top      
        if (!map.ContainsKey(key))
            return null;
        LRUNode node = map[key];
        recentNewsList.RemoveNode(node);
        recentNewsList.AddToTop(node);
        return map[key].Value;

    }

    public void Add(int key, News value)
    {
        //update the value and move it to the top
        if (map.ContainsKey(key))
        {
            LRUNode node = map[key];
            recentNewsList.RemoveNode(node);
            node.Value = value;
            recentNewsList.AddToTop(node);
        }
        else
        {
            // if cache is full, remove the least recently used node
            if (count == capacity)
            {
                LRUNode cache = recentNewsList.RemoveLRUNode();
                map.Remove(cache.Key);
                count--;
            }

            //add a new node
            LRUNode node = new LRUNode(key, value);
            recentNewsList.AddToTop(node);
            map[key] = node;
            count++;
        }
    }

    public void MoveToTop(int key)
    {
        LRUNode node = map[key];
        recentNewsList.RemoveNode(node);
        node.Key = key;
        recentNewsList.AddToTop(node);
    }


}
*/

public class LRUCache
{
    private readonly int capacity;
    private readonly Hashtable cacheMap;
    private CacheNode headNode;
    private CacheNode tailNode;

    private class CacheNode
    {
        public object Key { get; set; }
        public News Value { get; set; }
        public CacheNode Prev { get; set; }
        public CacheNode Next { get; set; }
    }

    public LRUCache(int capacity)
    {
        this.capacity = capacity;
        cacheMap = new Hashtable();
    }

    public void Add(object key, object value)
    {
        // If the key is already in the cache, update its value and move it to the front of the list.
        if (cacheMap.ContainsKey(key))
        {
            var node = (CacheNode)cacheMap[key];
            node.Value = (News)value;
            MoveNodeToFront(node);
        }
        else
        {
            // If the cache is full, remove the least recently used node (the tail node).
            if (cacheMap.Count == capacity)
            {
                RemoveTailNode();
            }

            // Create a new node with the specified key and value, and add it to the front of the list.
            var node = new CacheNode
            {
                Key = key,
                Value = (News) value,
                Prev = null,
                Next = headNode
            };
            if (headNode != null)
            {
                headNode.Prev = node;
            }
            headNode = node;

            // If the cache was empty, set the tail node to be the new node.
            if (tailNode == null)
            {
                tailNode = node;
            }

            // Add the new node to the cache map.
            cacheMap.Add(key, node);
        }
    }

    public object Get(object key)
    {
        // If the key is not in the cache, return null.
        if (!cacheMap.ContainsKey(key))
        {
            return null;
        }

        // Move the node with the specified key to the front of the list and return its value.
        var node = (CacheNode)cacheMap[key];
        MoveNodeToFront(node);
        return node.Value;
    }

    private void MoveNodeToFront(CacheNode node)
    {
        // If the node is already at the front of the list, do nothing.
        if (node == headNode)
        {
            return;
        }

        // If the node is at the tail of the list, update the tail node to be its predecessor.
        if (node == tailNode)
        {
            tailNode = node.Prev;
        }

        // Remove the node from its current position in the list.
        if (node.Prev != null)
        {
            node.Prev.Next = node.Next;
        }
        if (node.Next != null)
        {
            node.Next.Prev = node.Prev;
        }

        // Move the node to the front of the list.
        node.Prev = null;
        node.Next = headNode;
        headNode.Prev = node;
        headNode = node;
    }

    private void RemoveTailNode()
    {
        // Remove the tail node from the cache map.
        cacheMap.Remove(tailNode.Key);

        // If the cache had only one node, set both head and tail nodes to null.
        if (headNode == tailNode)
        {
            headNode = null;
            tailNode = null;
        }
        else
        {
            // Update the tail node to be the predecessor of the current tail.
            tailNode = tailNode.Prev;
            tailNode.Next = null;
        }
    }

    public void Print()
    {
           int count = 0;
        CacheNode node = headNode;
        while (headNode.Next != null && count < capacity)
        {
            Console.WriteLine($"ID: {node.Key}\nTime: {node.Value.Time}\nKeywords: {node.Value.Keywords}\n Content: {node.Value.Content}\n Hits: {node.Value.Hits}");
            node = node.Next;
            count++;
            
        }
    }

}



//Trending News
public class TrendingNewsPriorityQueue
{
    private Node head;

    public void Enqueue(News data, int priority)
    {
        Node newNode = new Node(data, priority);
        if (head == null)
        {
            head = newNode;
        }
        else if (priority > head.priority)
        {
            newNode.next = head;
            head = newNode;
        }
        else
        {
            Node current = head;
            while (current.next != null && priority <= current.next.priority)
            {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public News Dequeue()
    {
        if (head == null)
        {
            throw new Exception("Queue is empty");
        }
        News data = head.data;
        head = head.next;
        return data;
    }

    public int Count
    {
        get
        {
            int count = 0;
            Node current = head;
            while (current != null)
            {
                count++;
                current = current.next;
            }
            return count;
        }
    }

    public void Print()
    {
        Node current = head;
        while (current != null)
        {
            Console.WriteLine("News ID: {0}\nTime: {1}\nContent: {2}\nKeywords: {3}\nHits: {4}\n",
                current.data.ID, current.data.Time, current.data.Content,
                string.Join(", ", current.data.Keywords), current.data.Hits);
            current = current.next;
        }
    }

}



//Recent News

/*
public class RecentNewsLinkedList
{
    private LRUNode Head;
    private LRUNode Tail;

    public RecentNewsLinkedList()
    {
        Head = new LRUNode();
        Tail = new LRUNode();
        Head.Next = Tail;
        Tail.Previous = Head;
    }

    public void AddToTop(LRUNode node)
    {
        node.Next = Head.Next;
        Head.Next.Previous = node;
        node.Previous = Head;
        Head.Next = node;
    }

    public void RemoveNode(LRUNode node)
    {
        node.Previous.Next = node.Next;
        node.Next.Previous = node.Previous;
        node.Next = null;
        node.Previous = null;
    }

    public LRUNode RemoveLRUNode()
    {
        LRUNode target = Tail.Previous;
        RemoveNode(target);
        return target;
    }

    public void Print()
    {
        LRUNode current = Head;
        while(current != null)
        {
            Console.WriteLine("Key: " + current.Key + ", Value: " + current.Value);

            current = current.Next;
        }
    }
}
*/

    public class Run
    {
        public static void Main(String[] args)
        {
            // Initializing the LRU cache, PriorityQueue, and LinkedList
            const int cacheCapacity = 5;
            LRUCache cache = new LRUCache(cacheCapacity);
            //RecentNewsLinkedList recentNews = new RecentNewsLinkedList();
            TrendingNewsPriorityQueue trendingNews = new TrendingNewsPriorityQueue();

            // Load news from JSON file and add them to the cache, linked list, and Queue
            List<News> newsList = LoadNewsFromJson("E:\\Brian\\backup\\Important\\Lasalle College\\Classes\\Semester 4\\DataStructure\\ConsoleAppProjectDataStructure\\ConsoleAppProjectDataStructure\\MOCK_DATA.json");
            foreach (News news in newsList)
            {
                cache.Add(news.ID, news);
                trendingNews.Enqueue(news, news.Hits);
            }


            while (true)
            {
                Console.WriteLine("Please select an option:");
                Console.WriteLine("1. SHOW");
                Console.WriteLine("2. SELECT");
                Console.WriteLine("3. BACK");
                Console.WriteLine("4. SET");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        // Perform action for SHOW
                        Console.WriteLine("\n1. Recent\n2. Trending");
                        int result = Convert.ToInt32(Console.ReadLine());

                        if (result == 1)
                        {
                        cache.Print();
                        }
                        else
                        {
                            trendingNews.Print();
                        }

                        break;
                    case 2:
                        Console.WriteLine("You chose SELECT.");
                        Console.WriteLine("Please enter the ID of the news you want to view:");
                        int id = Convert.ToInt32(Console.ReadLine());
                        News news = (News) cache.Get(id); // get the news with the specified ID
                        Console.WriteLine("News ID: {0}\nTime: {1}\nContent: {2}\nKeywords: {3}\nHits: {4}\n",
                            news.ID, news.Time, news.Content, string.Join(", ", news.Keywords), news.Hits);
                         // move the news to the top of the cache
                        
                        break;
                    case 3:
                        Console.WriteLine("You chose BACK.");
                        // Perform action for BACK
                        break;
                    case 4:
                        Console.WriteLine("You chose SET.");
                        // Perform action for SET
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }


        }
        //Methods and Functions


        //Loading the JSON File
        public static List<News> LoadNewsFromJson(string filePath)
        {
            List<News> newsList = new List<News>();
            try
            {
                string json = File.ReadAllText(filePath);
                JsonDocument doc = JsonDocument.Parse(json);
                JsonElement root = doc.RootElement;

                if (root.ValueKind == JsonValueKind.Array)
                {
                    foreach (JsonElement element in root.EnumerateArray())
                    {
                        News news = new News();
                        news.ID = element.GetProperty("ID").GetInt32();
                        news.Time = long.Parse(element.GetProperty("Time").ToString());
                        news.Content = element.GetProperty("Content").GetString();
                        JsonElement keywordsElement = element.GetProperty("Keywords");
                        if (keywordsElement.ValueKind == JsonValueKind.Array)
                        {
                            news.Keywords = keywordsElement.EnumerateArray().Select(e => e.GetString()).ToArray();
                        }
                        news.Hits = element.GetProperty("Hits").GetInt32();
                        newsList.Add(news);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading news from JSON: {ex.Message}");
            }
            return newsList;
        }
    

}



